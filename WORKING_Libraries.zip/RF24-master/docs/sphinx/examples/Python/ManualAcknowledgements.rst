manual_acknowledgements.py
==========================

.. literalinclude:: ../../../../examples_linux/manual_acknowledgements.py
    :language: python
    :caption: examples_linux/manual_acknowledgements.py
    :linenos:
    :lineno-match:
