streamingData
==================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/streamingData.cpp
    :caption: examples_pico/streamingData.cpp
    :linenos:
