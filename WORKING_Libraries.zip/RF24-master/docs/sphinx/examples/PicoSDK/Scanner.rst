scanner
==================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/scanner.cpp
    :caption: examples_pico/scanner.cpp
    :linenos:
