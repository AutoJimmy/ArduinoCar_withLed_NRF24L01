Enumerations
============


.. doxygengroup:: PALevel
    :members:

.. doxygengroup:: Datarate
    :members:

.. doxygengroup:: CRCLength
    :members:
